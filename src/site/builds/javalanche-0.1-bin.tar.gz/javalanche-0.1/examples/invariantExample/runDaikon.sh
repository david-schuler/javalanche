#! /bin/sh
nice -10 java -Xmx2048m -cp ../..//lib/daikon-local.jar daikon.Daikon --no_text_output -o ${2} ${1} 
