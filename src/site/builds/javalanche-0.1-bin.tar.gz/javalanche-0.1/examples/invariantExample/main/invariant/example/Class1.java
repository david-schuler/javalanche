package invariant.example;

public class Class1 {

	public int method1(int limit) {
		return new Class2().m1(limit * 10);
	}

}
