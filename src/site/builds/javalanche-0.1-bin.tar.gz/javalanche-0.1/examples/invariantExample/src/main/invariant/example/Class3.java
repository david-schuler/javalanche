package invariant.example;

public class Class3 {

	public int method1(int i) {
		if (i == 20) {
			return 1000;
		}
		return 0;
	}
}
