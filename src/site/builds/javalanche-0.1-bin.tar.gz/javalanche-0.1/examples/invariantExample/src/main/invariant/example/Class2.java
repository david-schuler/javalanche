package invariant.example;

public class Class2 {

	public int m1(int i) {
		return i / 2;
	}

}
