/**
 * 
 */
package triangle;

public enum TriangleType {
	INVALID, SCALENE, EQUILATERAL, ISOSCELES
}